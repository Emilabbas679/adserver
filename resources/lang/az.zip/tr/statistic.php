<?php 
 return [
 
"statistic_details" => "İstatistik Detayları",

 ]; 