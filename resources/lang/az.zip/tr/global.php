<?php 
 return [
 
"statistics" => "İstatistikler",

"publisher" => "Yayıncı",

"advertiser" => "Reklamveren",

"showallnotifications" => "Tümünü Göster",

"notifications" => "Bildirimler",

 ]; 