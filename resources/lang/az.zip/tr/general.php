<?php 
 return [
 
"search_campaign" => "Kampanya Ara",

"date_text" => "Tarih",

"datetext" => "Tarih",

"bugdet_spent" => "Harcanan Bütçe",

"status" => "Durum",

"remaining_budget" => "Kalan Bütçe",

"budget_spend" => "Kullanılan Bütçe",

"budget" => "Bütçe",

"campaign" => "Kampanya",

"marketing_campaigns" => "Reklam Kampanyaları",

"select_ad" => "Reklam Seçin",

"daily_ad_performance" => "Günlük reklam performans",

"all_campaign_performance" => "Tüm Kampanyaların Performasnı",

"support" => "Destek",

"homepage" => "Yönetim",

"dashboard" => "Yönetim paneli",

"printselected" => "Seçimi Yazdır",

"printall" => "Tümünü Yazdır",

"print" => "Yazdır",

"menu" => "Menü",

 ]; 