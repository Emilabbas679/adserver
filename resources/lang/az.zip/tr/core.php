<?php 
 return [
 
"friday" => "Cümə",

"saturday" => "Şənbə",

"sunday" => "Bazar",

"thursday" => "Cümə axşamı",

"wednesday" => "Çərşənbə",

"tuesday" => "Çərşənbə axşamı",

"monday" => "Bazar ertəsi",

"notice" => "WARNING",

"upload_failed_server_cannot_handle_files_size_larger_then_file_size" => "Upload failed. Server cannot handle files ({size}) larger then: {file_size}",

"login_to_your_account" => "Login to your account",

"cached_cleared" => "Keş silindi.",

"farid" => "Kullanıcı Adı Değiştirilemez",

"notifications" => "Notifications",

"view_all_notifications" => "View All Notifications",

"previous" => "əvvəlki",

"next" => "növbəti",

"select" => "Seç",

"dashboard" => "ANA SAYFA",

"december" => "December",

"november" => "November",

"october" => "October",

"september" => "September",

"august" => "August",

"july" => "July",

"june" => "June",

"may" => "Mayis",

"april" => "Nisan",

"march" => "March",

"february" => "February",

"january" => "",

"day" => "gün",

"year" => "il",

"month" => "ay",

"are_you_sure" => "Silme işlemi yapmaya hazır mısınız?",

"delete" => "SİL",

"tools" => "Ayarlar",

"submit" => "Dahil et",

"reloadpage" => "Sayfa yenilenir, bekleyin...",

"first" => "İlk",

"page_x_of_x" => "Sayfa {current} of {total}",

"mail_signature" => "Regards,
{site_name} Team
www.adsgarden.com
{site_email}
Skype: adsgarden",

"hello" => "Merhaba",

"error" => "Yanlış!",

"edit" => "Düzeltme",

"last" => "Sonuncu",

"success" => "Tamamlandı",

 ]; 