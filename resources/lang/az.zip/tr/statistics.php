<?php 
 return [
 
"statistic_details" => "İstatistik Detayları",

"spent" => "Xərclər.",

"campaign" => "Kampaniya.",

"websitenostats" => "Web sitesiyle ilgili istatistik yoktur.",

"statistics" => "İstatistikler",

"pub_stats" => "Yayıncı İstatistikleri",

"main_page" => "Anasayfa",

"total" => "Toplam",

"viewmore" => "Detay Görüntüle",

"undefined" => "Tanımlanmamış",

"os" => "İşletim Sistemi",

"devices" => "Cihazlar",

"technology" => "Teknoloji",

"elanyox" => "Bu reklam için istatistik yok",

"hecyox" => "Sistemde Kapmaynanız bulunmuyor",

"demography" => "Demografi",

"spent_info" => "Harcama İstatistikleri",

"geo" => "Bölgesel İstatistikler",

"website" => "İnternet Sitesi",

"spent_amount" => "Harcanan Miktar",

"unique_click_count" => "Benzersiz Tıklama Sayısı",

"click_count" => "Tıklama Sayısı",

"unique_impression_count" => "Benzersiz Gösterim Sayısı (günlük)",

"impression_count" => "Gösterim Sayısı",

"website_statistics" => "Web Sitesi İstatistikleri",

"navigation" => "Navigasyon",

"campaign_statistics" => "Kampanya İstatistikleri",

 ]; 