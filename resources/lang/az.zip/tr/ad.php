<?php 
 return [
 
"successfully_updated" => "Güncelleme başarılı",

 ]; 