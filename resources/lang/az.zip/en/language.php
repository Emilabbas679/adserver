<?php 
 return [
 
"phrase" => "Translations",

"impression_unique_count" => "Unique impressions (daily)",

"phrase_title" => "Search for translations",

"phrase_list" => "Translations",

"language_phrase" => "Translations",

"phrase_variables" => "Developer",

"language_package_successfully_added" => "Dil paketi əlavə edildi",

"select" => "Dil seç",

"save_all" => "Yadda saxla",

"original" => "Əsli",

"language" => "Dil",

"variable" => "Sabit",

"varname" => "Sabit",

"module" => "Modul",

"submit" => "Yadda  saxlanıldı",

"language_package_successfully_updated" => "Yadda saxlanıldı",

"name" => "Name",

"create_title" => "Dil yarat",

"phrase_added" => "Created",

"text" => "TEXT",

"js" => "JS",

"html" => "HTML",

"php" => "php",

"php_double_quoted" => "PHP Double Quoted",

"php_single_quoted" => "PHP Single Quoted",

 ]; 