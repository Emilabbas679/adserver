<?php 
 return [
 
"not_a_valid_email" => "Not a valid email",

 ]; 