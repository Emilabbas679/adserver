<?php 
 return [
 
"search_campaign" => "Search for Campaigns",

"date_text" => "Date",

"datetext" => "Date",

"bugdet_spent" => "Budget Spent",

"status" => "Status",

"remaining_budget" => "Remaining Budget",

"budget_spend" => "Budget Spent",

"budget" => "Budget",

"campaign" => "Campaigns",

"marketing_campaigns" => "Ad campaigns",

"select_ad" => "Select advertisement",

"daily_ad_performance" => "Daily ad performance",

"all_campaign_performance" => "Performance of all campaigns",

"support" => "Support",

"homepage" => "Home",

"dashboard" => "Dashboard",

"printselected" => "Print Selected",

"printall" => "Print All",

"print" => "Print",

"menu" => "Menu",

 ]; 