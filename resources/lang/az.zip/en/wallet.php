<?php 
 return [
 
"delete_wallet" => "Pul kisəsi silindi",

"create_wallet" => "Create wallet",

 ]; 