<?php 
 return [
 
"statistic_details" => "Statistics Details",

 ]; 