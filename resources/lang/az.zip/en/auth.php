<?php 
 return [
"publisher_welcome" => "Enter system, manage your ad campaigns. If you face any problems, feel free to contact us.",
"user_request_new_pass" => "Request New Password",
"hesabin_var" => "Already registered?",
"register" => "Register",
"smartbee_platform" => "SmartBee Reklam platforması",
"reset_pass" => "Forgot password?",
"remember_me" => "Remember me",
"advertiser_welcome" => "Enter system, manage your ad campaigns. If you face any problems, feel free to contact us.",
"return_home" => "Return to homepage",
"login" => "Enter",
"hesabn_yoxdur" => "Do not have account?",
"publisher_title" => "Publisher",
"advertiser_title" => "Advertiser",
"welcome" => "Smart bees are greeting you!",
];