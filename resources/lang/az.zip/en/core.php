<?php 
 return [
 
"friday" => "Sriday",

"saturday" => "Saturday",

"sunday" => "Sunday",

"thursday" => "Thursday",

"wednesday" => "Wednesday",

"tuesday" => "Tuesday",

"monday" => "Monday",

"notice" => "WARNING",

"upload_failed_server_cannot_handle_files_size_larger_then_file_size" => "Upload failed. Server cannot handle files ({size}) larger then: {file_size}",

"login_to_your_account" => "Login to your account",

"cached_cleared" => "Cache is cleaned",

"farid" => "Username cannot be changed",

"notifications" => "Notifications",

"view_all_notifications" => "View All Notifications",

"previous" => "əvvəlki",

"next" => "növbəti",

"select" => "Seç",

"dashboard" => "ANA SƏHİFƏ",

"december" => "December",

"november" => "November",

"october" => "October",

"september" => "September",

"august" => "August",

"july" => "July",

"june" => "June",

"may" => "May",

"april" => "April",

"march" => "March",

"february" => "February",

"january" => "",

"day" => "Day",

"year" => "il",

"month" => "ay",

"are_you_sure" => "Ready to delete erase?",

"delete" => "SİL",

"tools" => "Actions",

"submit" => "Daxil et",

"reloadpage" => "Səhifə yenilənir gözləyin...",

"first" => "İlk",

"page_x_of_x" => "Səhifə {current} of {total}",

"mail_signature" => "Regards,
{site_name} Team
www.adsgarden.com
{site_email}
Skype: adsgarden",

"hello" => "Salam",

"error" => "Səhv!",

"edit" => "Edit",

"last" => "Last",

"success" => "Success",

 ]; 