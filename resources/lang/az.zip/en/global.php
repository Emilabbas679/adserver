<?php 
 return [
 
"statistics" => "Statistics",

"publisher" => "Publisher",

"advertiser" => "Advertiser",

"showallnotifications" => "Show All",

"notifications" => "Notifications",

 ]; 