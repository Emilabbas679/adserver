<?php 
 return [
 
"statistic_details" => "Statistics Details",

"spent" => "Xərclər.",

"campaign" => "Kampaniya.",

"websitenostats" => "There are no statistics about the website.",

"statistics" => "Statistics",

"pub_stats" => "Publisher Statistics",

"main_page" => "Homepage",

"total" => "Total",

"viewmore" => "View details",

"undefined" => "Undefined",

"os" => "Operating System",

"devices" => "Devices",

"technology" => "Technology",

"elanyox" => "No statistics available for this ad",

"hecyox" => "You have no campaign",

"demography" => "Demography",

"spent_info" => "Spent Statistics",

"geo" => "Regional Statistics",

"website" => "Website",

"spent_amount" => "Spent Amount",

"unique_click_count" => "Unique Clicks",

"click_count" => "Clicks",

"unique_impression_count" => "Unique Impressions (daily)",

"impression_count" => "Impressions",

"website_statistics" => "Website Statistics",

"navigation" => "Navigation",

"campaign_statistics" => "Campaign Statistics",

 ]; 