<?php 
 return [
"support" => "Dəstək",
"faq" => "FAQ",
"ads_advert" => "Reklam elanları",
"search" => "Axtar",
"campaigns" => "Kampaniyalar",
"search_in_campaigns" => "Kampaniyalarda axtar",
"statistics" => "Statistika",
"delete" => "Sil",
"edit" => "Redaktə et",
"stop" => "Dayandır",
"admin_stop" => "Admin tərəfindən dayandır",
"campaign_list" => "Kampaniyalar",
"adset_group" => "Adset group",
"homepage" => "Home",
];