<?php 
 return [
"searching" => "Searching",
"username" => "İstifadəçi adı",
"all_statuses" => "Bütün statuslar",
"campaign_name" => "Kampaniya adı",
"user_password" => "Password",
"user_email" => "Username",
];