<?php 
 return [
 
"statistics" => "Статистика",

"publisher" => "издатель",

"advertiser" => "рекламодатель",

"showallnotifications" => "Показать все",

"notifications" => "Уведомления",

 ]; 