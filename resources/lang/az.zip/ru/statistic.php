<?php 
 return [
 
"statistic_details" => "Статистика Подробности",

 ]; 