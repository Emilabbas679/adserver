<?php 
 return [
"publisher_welcome" => "Enter system, manage your ad campaigns. If you face any problems, feel free to contact us.",
"user_request_new_pass" => "Request New Password",
"hesabin_var" => "Уже зарегистрировались?",
"register" => "Регистрация",
"smartbee_platform" => "SmartBee Reklam platforması",
"reset_pass" => "Забыли парол?",
"remember_me" => "Запомнить меня",
"advertiser_welcome" => "Enter system, manage your ad campaigns. If you face any problems, feel free to contact us.",
"return_home" => "На главную страницу",
"login" => "Войти",
"hesabn_yoxdur" => "У вас нет учетного записи?",
"publisher_title" => "Паблишер",
"advertiser_title" => "Рекламодатель",
"welcome" => "Пчелы приветствуют вас!",
];