<?php 
 return [
 
"friday" => "Cümə",

"saturday" => "Şənbə",

"sunday" => "Bazar",

"thursday" => "Cümə axşamı",

"wednesday" => "Çərşənbə",

"tuesday" => "Çərşənbə axşamı",

"monday" => "Bazar ertəsi",

"notice" => "ВНИМАНИЕ",

"upload_failed_server_cannot_handle_files_size_larger_then_file_size" => "Upload failed. Server cannot handle files ({size}) larger then: {file_size}",

"login_to_your_account" => "Login to your account",

"cached_cleared" => "Кеш очищена",

"farid" => "Имя пользователя не может быть изменено",

"notifications" => "Уведомления",

"view_all_notifications" => "Все уведомлении",

"previous" => "əvvəlki",

"next" => "növbəti",

"select" => "Seç",

"dashboard" => "ANA SƏHİFƏ",

"december" => "December",

"november" => "November",

"october" => "October",

"september" => "September",

"august" => "August",

"july" => "July",

"june" => "June",

"may" => "May",

"april" => "April",

"march" => "March",

"february" => "February",

"january" => "",

"day" => "gün",

"year" => "il",

"month" => "ay",

"are_you_sure" => "<div><font face='Arial, Verdana'><span style='font-size: 12px;'>&nbsp;Вы готов к операции удаления?</span></font></div><div style='font-family: Arial, Verdana; font-size: 12px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal;'><br></div>",

"delete" => "SİL",

"tools" => "Действие",

"submit" => "Daxil et",

"reloadpage" => "Səhifə yenilənir gözləyin...",

"first" => "İlk",

"page_x_of_x" => "Səhifə {current} of {total}",

"mail_signature" => "Regards,
{site_name} Team
www.adsgarden.com
{site_email}
Skype: adsgarden",

"hello" => "Salam",

"error" => "Səhv!",

"edit" => "Коррекция",

"last" => "Sonuncu",

"success" => "Tamamlandı",

 ]; 