<?php 
 return [
 
"successfully_updated" => "Успешно обновлено",

 ]; 