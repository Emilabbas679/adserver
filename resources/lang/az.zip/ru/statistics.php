<?php 
 return [
 
"statistic_details" => "Статистика Подробности",

"spent" => "Xərclər.",

"campaign" => "Kampaniya.",

"websitenostats" => "Нет статистики по сайту.",

"statistics" => "Статистика",

"pub_stats" => "Статистика издателя",

"main_page" => "домашняя страница",

"total" => "Общее количество",

"viewmore" => "Посмотреть детали",

"undefined" => "не определено",

"os" => "Операционная система",

"devices" => "приборы",

"technology" => "Технологии",

"elanyox" => "Статистика по этому объявлению недоступна",

"hecyox" => "У вас нет кампании",

"demography" => "демография",

"spent_info" => "Потраченная статистика",

"geo" => "Региональная статистика",

"website" => "Интернет сайт",

"spent_amount" => "Потраченная сумма",

"unique_click_count" => "Уникальный Счетчик Кликов",

"click_count" => "Нажмите Количество",

"unique_impression_count" => "Уникальное количество показов (дневные)",

"impression_count" => "Количество показов",

"website_statistics" => "Статистика сайта",

"navigation" => "навигация",

"campaign_statistics" => "Статистика кампании",

 ]; 