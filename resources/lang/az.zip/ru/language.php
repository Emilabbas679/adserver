<?php 
 return [
 
"phrase" => "Tərcümə",

"impression_unique_count" => "Уникальные показы",

"phrase_title" => "Tərcümə axtarış",

"phrase_list" => "Переводы",

"language_phrase" => "Переводы",

"phrase_variables" => "Developer",

"language_package_successfully_added" => "Dil paketi əlavə edildi",

"select" => "Dil seç",

"save_all" => "Yadda saxla",

"original" => "Əsli",

"language" => "Dil",

"variable" => "Sabit",

"varname" => "Sabit",

"module" => "Modul",

"submit" => "Yadda  saxlanıldı",

"language_package_successfully_updated" => "Yadda saxlanıldı",

"name" => "Adı",

"create_title" => "Dil yarat",

"phrase_added" => "Yaradıldı",

"text" => "TEXT",

"js" => "JS",

"html" => "HTML",

"php" => "php",

"php_double_quoted" => "PHP Double Quoted",

"php_single_quoted" => "PHP Single Quoted",

 ]; 