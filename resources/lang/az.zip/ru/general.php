<?php 
 return [
 
"search_campaign" => "Поиск кампаний",

"date_text" => "история",

"datetext" => "история",

"bugdet_spent" => "Потраченный бюджет",

"status" => "Потраченный бюджет",

"remaining_budget" => "Оставшийся бюджет",

"budget_spend" => "Потраченный бюджет",

"budget" => "бюджет",

"campaign" => "кампания",

"marketing_campaigns" => "Маркетинговые кампании",

"select_ad" => "Выберите объявление",

"daily_ad_performance" => "Ежедневная эффективность рекламы",

"all_campaign_performance" => "Выполнение всех кампаний",

"support" => "поддержка",

"homepage" => "Домашняя страница",

"dashboard" => "приборная панель",

"printselected" => "Печать выбранных",

"printall" => "Распечатать все",

"print" => "печать",

"menu" => "Меню",

 ]; 