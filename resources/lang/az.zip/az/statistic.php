<?php 
 return [
 
"statistic_details" => "Statistika təfərrüatları",

 ]; 