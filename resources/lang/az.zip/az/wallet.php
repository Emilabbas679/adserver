<?php 
 return [
 
"delete_wallet" => "Pul kisəsi silindi",

"create_wallet" => "Pul kisəsinin yaradılması",

 ]; 