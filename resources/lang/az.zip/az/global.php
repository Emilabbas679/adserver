<?php 
 return [
 
"statistics" => "Statistika",

"publisher" => "Yayımçı",

"advertiser" => "Reklamçı",

"showallnotifications" => "Hamısını göstər",

"notifications" => "Bildirişlər",

 ]; 