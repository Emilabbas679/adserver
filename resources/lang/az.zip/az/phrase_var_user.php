<?php 
 return [
 
"not_a_valid_email" => "E-poçt düzgün deyil",

 ]; 