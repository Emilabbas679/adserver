<?php 
 return [
"publisher_welcome" => "Sistemə daxil olun, reklamınızı idarə edin. Hər hansı çətinlik yarandığı zaman bizimlə əlaqə saxlayın.",
"user_request_new_pass" => "Şifrəni yenilə",
"hesabin_var" => "Mövcud hesabın var?",
"register" => "Qeydiyyat",
"smartbee_platform" => "SmartBee Reklam platforması",
"reset_pass" => "Şifrəni unutmusunuz?",
"remember_me" => "Məni yadda saxla",
"advertiser_welcome" => "Sistemə daxil olun, reklamınızı idarə edin. Hər hansı çətinlik yarandığı zaman bizimlə əlaqə saxlayın.",
"return_home" => "Ana səhifəyə qayıt",
"login" => "Daxil ol",
"hesabn_yoxdur" => "Hesabın yoxdur?",
"publisher_title" => "Yayınçı",
"advertiser_title" => "Reklamverən",
"welcome" => "Arılar sizi salamlayır.",
];