<?php 
 return [
 
"if_uploading_vide_file" => "Video fayl yüklənirsə:",

 ]; 