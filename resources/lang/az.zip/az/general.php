<?php 
 return [
 
"search_campaign" => "Kampaniyalar üçün axtarış",

"date_text" => "Tarix",

"datetext" => "Tarix",

"bugdet_spent" => "Büdcə xərcləndi",

"status" => "Status",

"remaining_budget" => "Qalan Büdcə",

"budget_spend" => "Büdcə xərcləndi",

"budget" => "Büdcə",

"campaign" => "Kampaniyalar",

"marketing_campaigns" => "Marketinq Kampaniyaları",

"select_ad" => "Elan Seçin",

"daily_ad_performance" => "Gündəlik Elan performansı",

"all_campaign_performance" => "Bütün Kampaniyaların performansı",

"support" => "Dəstək",

"homepage" => "Əsas Səhifə",

"dashboard" => "İdarə paneli",

"printselected" => "Seçilmişləri çap et",

"printall" => "Hamısını çap edin",

"print" => "Çap",

"menu" => "Menyu",

 ]; 