<?php 
 return [
 
"successfully_updated" => "Uğurla yeniləndi",

 ]; 