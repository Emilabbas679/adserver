<?php 
 return [
"searching" => "Axtarılır",
"username" => "İstifadəçi adı",
"all_statuses" => "Bütün statuslar",
"campaign_name" => "Kampaniya adı",
"user_password" => "Şifrə",
"user_email" => "İstifadəçi adl",
];