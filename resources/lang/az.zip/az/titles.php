<?php 
 return [
"campaign" => "Kampaniyalar",
"advertiser_login" => "Smartbee Reklam platforması",
"publisher_register" => "Smartbee Reklam platforması",
"publisher_login" => "Smartbee Reklam platforması",
"publisher_title" => "Smartbee Reklam platforması",
"publisher_password" => "Smartbee Reklam platforması",
"advertiser_password" => "Smartbee Reklam platforması",
"advertiser_register" => "Smartbee Reklam platforması",
"advertiser_title" => "Smartbee Reklam platforması",
"login" => "Smartbee Reklam platforması",
];