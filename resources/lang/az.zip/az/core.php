<?php 
 return [
 
"friday" => "Cümə",

"saturday" => "Şənbə",

"sunday" => "Bazar",

"thursday" => "Cümə axşamı",

"wednesday" => "Çərşənbə",

"tuesday" => "Çərşənbə axşamı",

"monday" => "Bazar ertəsi",

"notice" => "DİQQƏT",

"upload_failed_server_cannot_handle_files_size_larger_then_file_size" => "Upload failed. Server cannot handle files ({size}) larger then: {file_size}",

"login_to_your_account" => "Login to your account",

"cached_cleared" => "Keş silindi.",

"farid" => "Kullanıcı Adı Değiştirilemez",

"notifications" => "Notifications",

"view_all_notifications" => "View All Notifications",

"previous" => "əvvəlki",

"next" => "növbəti",

"select" => "Seç",

"dashboard" => "ANA SƏHİFƏ",

"december" => "Dekabr",

"november" => "Noyabr",

"october" => "Oktyabr",

"september" => "Sentyabr",

"august" => "Avqust",

"july" => "İyul",

"june" => "İyun",

"may" => "May",

"april" => "Aprel",

"march" => "Mart",

"february" => "Fevral",

"january" => "Yanvar",

"day" => "gün",

"year" => "il",

"month" => "ay",

"are_you_sure" => "Silmə əməliyyatı etməyə hazırsız?",

"delete" => "SİL",

"tools" => "Dəyişmək",

"submit" => "Daxil et",

"reloadpage" => "Səhifə yenilənir, gözləyin...",

"first" => "İlk",

"page_x_of_x" => "Səhifə {current} of {total}",

"mail_signature" => "Regards,
{site_name} Team
www.adsgarden.com
{site_email}
Skype: adsgarden",

"hello" => "Salam",

"error" => "Səhv!",

"edit" => "Düzəliş",

"last" => "Sonuncu",

"success" => "Tamamlandı",

 ]; 