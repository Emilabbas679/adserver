<?php 
 return [
 
"statistic_details" => "Statistika təfərrüatları",

"spent" => "Xərclər.",

"campaign" => "Kampaniya.",

"websitenostats" => "Veb sayt haqqında heç bir statistika yoxdur.",

"statistics" => "Statistika",

"pub_stats" => "Yayınçı Statistikası",

"main_page" => "Baş Səhifə",

"total" => "Ümumi",

"viewmore" => "Ətraflı məlumat",

"undefined" => "Təyin olunmamışdır",

"os" => "Əməliyyat sistemi",

"devices" => "Cihazlar",

"technology" => "Texnologiya",

"elanyox" => "Bu Elanla əlaqəli statistika yoxdur",

"hecyox" => "Kampaniyanız yoxdur.",

"demography" => "Demoqrafiya",

"spent_info" => "Sərf statistikası",

"geo" => "Regional statistika",

"website" => "Veb Sayt",

"spent_amount" => "Xərclənib",

"unique_click_count" => "Unikal Kliklər",

"click_count" => "Kliklər",

"unique_impression_count" => "Unikal göstərimlər (günlük)",

"impression_count" => "Göstərimlər",

"website_statistics" => "Veb sayt statistikası",

"navigation" => "Naviqasiya",

"campaign_statistics" => "Kampaniya statistikası",

 ]; 