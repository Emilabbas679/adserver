<?php 
 return [
"empty_result" => "Nəticə yoxdur",
];